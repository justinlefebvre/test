package com.example.a1354629.assignment1;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.graphics.Color;
import android.icu.text.DateFormat;
import android.icu.text.SimpleDateFormat;
import android.icu.util.Calendar;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import java.sql.Time;
import java.util.Date;


/**
 * A placeholder fragment containing a simple view.
 */
public class MainActivityFragment extends Fragment implements CircleView.OnClickListener {

    private EditText title;
    private EditText body;
    private TextView timeText;

    public MainActivityFragment() {

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View root = inflater.inflate(R.layout.fragment_main, container, false);



        CircleView c1 = (CircleView) root.findViewById(R.id.Note1);
        CircleView c2 = (CircleView) root.findViewById(R.id.Note2);
        CircleView c3 = (CircleView) root.findViewById(R.id.Note3);
        CircleView c4 = (CircleView) root.findViewById(R.id.Note4);
        CircleView c5 = (CircleView) root.findViewById(R.id.Note5);
        CircleView c6 = (CircleView) root.findViewById(R.id.Note6);
        CircleView c7 = (CircleView) root.findViewById(R.id.Note7);
        CircleView c8 = (CircleView) root.findViewById(R.id.Note8);

        c1.setColor(getResources().getColor(R.color.base08));
        c2.setColor(getResources().getColor(R.color.base09));
        c3.setColor(getResources().getColor(R.color.base0A));
        c4.setColor(getResources().getColor(R.color.base0B));
        c5.setColor(getResources().getColor(R.color.base0C));
        c6.setColor(getResources().getColor(R.color.base0D));
        c7.setColor(getResources().getColor(R.color.base0E));
        c8.setColor(getResources().getColor(R.color.base0F));

        title = (EditText) root.findViewById(R.id.editText);
        body = (EditText) root.findViewById(R.id.editText2);
        title.setBackgroundColor(Color.rgb(119,51,0));
        //EditText date = (EditText) root.findViewById(R.id.editText3);
        timeText = (TextView) root.findViewById(R.id.DatePickText);

        c1.setOnClickListener(this);
        c2.setOnClickListener(this);
        c3.setOnClickListener(this);
        c4.setOnClickListener(this);
        c5.setOnClickListener(this);
        c6.setOnClickListener(this);
        c7.setOnClickListener(this);
        c8.setOnClickListener(this);

        DatePicker handler = new DatePicker();
        timeText.setOnClickListener(handler);

        return root;
    }

    @Override
    public void onClick(View v) {
        CircleView c = (CircleView) v;
        title.setBackgroundColor(c.getColor());
        body.setBackgroundColor(c.getColor());
    }

    private void updateTime(int hourOfDay, int minute) {
        timeText.setText(String.valueOf(hourOfDay) + ":" + String.valueOf(minute));
    }



    private class DatePicker implements View.OnClickListener{

        @Override
        public void onClick(View v) {
            Date initial = new Date();   // TODO: use previous value or "tomorrow at 8:00"
            // create and show the TimePicker with starting time
            DialogFragment dialogFragment = TimePickerDialogFragment.create(
                    initial,
                    new TimePickerDialog.OnTimeSetListener() {
                        @Override
                        public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                            updateTime(hourOfDay, minute);
                        } });
            dialogFragment.show(getFragmentManager(), "timePicker");
        }
    }

}
